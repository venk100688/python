
try:
    x = 5
    y = 6
    z = x + y
    f = open("sesame.txt")
    print("Bottom of try")

except Exception as err: # Will catch _any_ exception
    print("Naughty programmer! ", err)
    if type(err) == FileNotFoundError():
        print("file error")
