fruits = ['apple', 'cherry', 'orange', 'kiwi', 'banana', 'pear', 'fig'] # list
name = "Eric Idle"  # str
knight = 'King', 'Arthur', 'Britain'  # tuple
data = b"abcde"   # bytes

print(fruits[3])  # print 4th element of fruits
print(name[2])  # print 3rd letter of name
print(knight[1])  # print 2nd element of knight
print(data[4])  # print 5th element of data
