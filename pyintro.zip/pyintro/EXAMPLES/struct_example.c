

struct person {
    char *fname;
    char *lname;
    int age;
}

