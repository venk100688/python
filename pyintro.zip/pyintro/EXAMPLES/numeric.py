
a = 5
b = 10
c = 20.22
d = 0o123        # Octal
e = 0xdeadbeef   # Hex
f = 0b10011101   # Binary 

print("a, b, c", a, b, c)
print("a + b", a + b)
print("a + c", a + c)
print("d", d)
print("e", e)
print("f", f)
