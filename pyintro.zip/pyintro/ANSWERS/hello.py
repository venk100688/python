print("Hello, world")

