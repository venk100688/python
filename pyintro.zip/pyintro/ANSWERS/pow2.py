for n in range(0, 32):
    print(f"{n:2d} {2 ** n:10d}")

for n in range (1,40):
    print(f"{n:10d}  {2**n:10d}")