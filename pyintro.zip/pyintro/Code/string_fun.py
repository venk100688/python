# -*- coding: utf-8 -*-
"""
Created on Mon Jun  3 15:49:27 2024

@author: Administrator
"""

name = "john jacbo just acbo"

print(name)
print(name.lower())
print(name.upper())
print(len(name))
print(name.count('j'))
print(name.index("jacbo"))
print("john" in name)
print(name.isalnum())
print(name.strip('j'))
print(name.replace("joh", "test"))

name1= "Venk"
name2= "atesh"

s=f"{name1} add {name2}"
print(s)