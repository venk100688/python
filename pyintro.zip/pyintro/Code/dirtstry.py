DIRTY_STRINGS = [
    "  mud   ",
    "grime  ",
    "   filth    ",
    "     messy messy     ",
    "DIRT	",
    "       FILTH and grime    ",
    "Dirt",
    "   Filth,    dirt, grime,    grime, grime, filth, and mud      ",
]


def cleanup():
    for old_string in DIRTY_STRINGS:
        return old_string.strip().lower()


t=cleanup()
print(t)