# -*- coding: utf-8 -*-


while True:
    cels=input("What is the cel?")
    if cels == '':
        print("Enter a Valid Number not Empty")
        continue
    if 'q' in cels.lower():
        print("Quit")
        break
    try:
        c = float(cels)
    except ValueError:
        print("Please Enter Valid Number")
        continue
    f = c * 9 / 5 + 32
    print ("{0}\u00b0 C is {1}\u00b0 F".format(c, f))
    
print("Progam exit")
