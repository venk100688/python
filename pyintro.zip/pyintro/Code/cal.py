# -*- coding: utf-8 -*-

def add(x,y):
    return x+y

def sub(x,y):
    return x+y

def mul(x,y):
    return x+y

def div(x,y):
    return x+y

def eq(x,y):
    z=x
    return z

while True:
    expr = input("Enter a math expression: ")
    v1, op, v2 = expr.split()
    v1 = float(v1)
    v2 = float(v2)
    
    if op == "+":
        result = add(v1, v2)
        break
print(result)