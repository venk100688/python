# -*- coding: utf-8 -*-

cels=input("What is the cel?")
cel=float(cels)
faren= ((9 * cel) / 5 ) + 32
print(faren)
print(f"Celcius of {cel} is eql farne will be {faren}")