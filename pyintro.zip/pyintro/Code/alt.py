# -*- coding: utf-8 -*-

    
# open("a.txt", "w").writelines(line for line in open("../DATA/alt.txt") if line[0] == "a")
# open("b.txt", "w").writelines(line for line in open("../DATA/alt.txt") if line[0] == "b")