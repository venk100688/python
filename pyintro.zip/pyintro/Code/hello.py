# -*- coding: utf-8 -*-

import sys

    
print ("hello world")

name ="Mark"
print("Hello", name)