# -*- coding: utf-8 -*-

import random
import sys

lower = 1
upper = 25

number = random.randint(lower, upper)

while True:
    print("my number is somewhere from ", lower, "to", upper)
   
    try:
        guess=int(input("Enter Guess Number"))
    except ValueError:
        print("Enter Valid Number")
        continue
  
    if guess > number:
        print("\n", guess, "is TOO HIGH")
    elif guess < number:
        print("\n", guess, "is TOO LOW")
    else:
        print("YOU GOT IT!")
        break

sys.exit(0)