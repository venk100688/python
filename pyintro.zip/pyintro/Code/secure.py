# -*- coding: utf-8 -*-

with open("secure.txt") as log_file:
    for line in log_file:
        if "Accepted password" in line:
            fields=line.split()
            print(f"IP address in {fields[-4]}")
            