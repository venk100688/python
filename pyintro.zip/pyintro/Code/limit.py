# -*- coding: utf-8 -*-

limit=100
is_prime=