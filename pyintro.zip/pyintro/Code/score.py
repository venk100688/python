# -*- coding: utf-8 -*-
from pprint import pprint
students = dict()

with open("../DATA/test_scores.txt") as test_score:
    for line in test_score:
        name,score=line.rstrip().split(":")
        score=int(score)
        students[name]=score


for name, score in students.items():
    if score > 95:
        grade="A"
    elif score > 89:
        grade = "B"
    else:
        grade = "C"
    pprint(f"{name} {score} {grade}")
        
        
    